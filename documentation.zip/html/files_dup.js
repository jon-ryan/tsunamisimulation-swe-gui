var files_dup =
[
    [ "gui.cpp", "gui_8cpp.html", null ],
    [ "gui.h", "gui_8h.html", [
      [ "Gui", "class_gui.html", "class_gui" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "scenario.cpp", "scenario_8cpp.html", null ],
    [ "scenario.h", "scenario_8h.html", "scenario_8h" ],
    [ "simulation.cpp", "simulation_8cpp.html", null ],
    [ "simulation.h", "simulation_8h.html", [
      [ "output_options", "structoutput__options.html", "structoutput__options" ],
      [ "sim_options", "structsim__options.html", "structsim__options" ],
      [ "simulation", "classsimulation.html", "classsimulation" ]
    ] ],
    [ "solver.h", "solver_8h.html", null ],
    [ "writer.h", "writer_8h.html", [
      [ "writer", "classwriter.html", "classwriter" ]
    ] ]
];