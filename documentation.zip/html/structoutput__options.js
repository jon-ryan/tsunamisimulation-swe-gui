var structoutput__options =
[
    [ "checkpoint_name", "structoutput__options.html#a52d340330e4792eab09e6c46c70450be", null ],
    [ "coarse_factor", "structoutput__options.html#a7da2bc1899d33432c5eaceb48fdd9776", null ],
    [ "create_output", "structoutput__options.html#ab07312735dc8f762164191e2dfb3330f", null ],
    [ "gui", "structoutput__options.html#a15e85587b450742cad9744e18ae3a0a9", null ],
    [ "max_num_timesteps", "structoutput__options.html#a00f4cf8ae251eabdd84f25c002ada3f3", null ],
    [ "output_name", "structoutput__options.html#a1d4499ffcdd0360a29d026f11dd240db", null ]
];