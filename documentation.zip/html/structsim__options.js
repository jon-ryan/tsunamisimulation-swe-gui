var structsim__options =
[
    [ "duration", "structsim__options.html#a6f80ac1c5d9ec8c313e271bce7d30488", null ],
    [ "num_cells", "structsim__options.html#ac22262416f6d346f1168bbf0bd307c32", null ],
    [ "num_threads", "structsim__options.html#aaea78227b81ba64e4272e2666ec56a3d", null ],
    [ "reflective_bounds", "structsim__options.html#a9d4a58df0d50cb1a8d8370c857a66297", null ]
];