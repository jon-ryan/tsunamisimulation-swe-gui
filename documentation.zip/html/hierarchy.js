var hierarchy =
[
    [ "output_options", "structoutput__options.html", null ],
    [ "scenario", "classscenario.html", [
      [ "artificial_tsunami_scenario", "classartificial__tsunami__scenario.html", null ],
      [ "file_scenario", "classfile__scenario.html", null ],
      [ "radial_dambreak_obstacle_scenario", "classradial__dambreak__obstacle__scenario.html", null ]
    ] ],
    [ "sim_options", "structsim__options.html", null ],
    [ "simulation", "classsimulation.html", null ],
    [ "Window", null, [
      [ "Gui", "class_gui.html", null ]
    ] ],
    [ "writer", "classwriter.html", null ]
];