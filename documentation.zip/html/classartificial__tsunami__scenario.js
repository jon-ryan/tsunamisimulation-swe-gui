var classartificial__tsunami__scenario =
[
    [ "get_bathymetry", "classartificial__tsunami__scenario.html#abededb1035ceac02c3fedfbcb28ec998", null ],
    [ "get_height", "classartificial__tsunami__scenario.html#a6f0ed99f129e9b436582dc47b0b63cb4", null ],
    [ "get_origin", "classartificial__tsunami__scenario.html#acd5cc190337be98036959de845a52b8d", null ],
    [ "get_size", "classartificial__tsunami__scenario.html#aa57dfb60d5d426f5dba587eecb5a6a68", null ]
];