var classwriter =
[
    [ "writer", "classwriter.html#a3f9f8f6dd43626347e7ddbc2c2257293", null ],
    [ "write", "classwriter.html#a7380304eef6aef81c2a2995e98c19f0c", null ]
];