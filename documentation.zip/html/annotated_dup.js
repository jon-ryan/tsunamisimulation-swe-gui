var annotated_dup =
[
    [ "artificial_tsunami_scenario", "classartificial__tsunami__scenario.html", "classartificial__tsunami__scenario" ],
    [ "file_scenario", "classfile__scenario.html", "classfile__scenario" ],
    [ "Gui", "class_gui.html", "class_gui" ],
    [ "output_options", "structoutput__options.html", "structoutput__options" ],
    [ "radial_dambreak_obstacle_scenario", "classradial__dambreak__obstacle__scenario.html", "classradial__dambreak__obstacle__scenario" ],
    [ "scenario", "classscenario.html", "classscenario" ],
    [ "sim_options", "structsim__options.html", "structsim__options" ],
    [ "simulation", "classsimulation.html", "classsimulation" ],
    [ "writer", "classwriter.html", "classwriter" ]
];